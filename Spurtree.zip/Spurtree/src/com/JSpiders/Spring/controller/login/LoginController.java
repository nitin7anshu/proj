package com.JSpiders.Spring.controller.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.Service.login.LoginService;


@Controller
@RequestMapping("/")
public class LoginController {

	@Autowired
	private LoginService loginservice;

	public LoginController() {
		System.out.println(this.getClass().getSimpleName() + "Created.....");
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public ModelAndView userLoginController(RegisterDTO dto, HttpServletRequest request) {
		System.out.println("Login controller is started......");
		RegisterDTO dtoFROMDB = loginservice.userLoginService(dto);
		if (dtoFROMDB != null) {
			HttpSession session = request.getSession();
			session.setAttribute("dto", dtoFROMDB);
			System.out.println("Login success......");
			System.out.println("Login controller ended.....");
			return new ModelAndView("Home.html");
		} else {
			System.out.println("Login controller is ended......");
			return new ModelAndView("Error.html");
		}
	}

}
