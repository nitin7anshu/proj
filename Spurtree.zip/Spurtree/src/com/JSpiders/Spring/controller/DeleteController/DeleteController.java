package com.JSpiders.Spring.controller.DeleteController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.JSpiders.Spring.DTO.delete.DeleteDTO;
import com.JSpiders.Spring.model.Service.DeleteService.DeleteService;

@Controller
@RequestMapping("/")
public class DeleteController {
	
	@Autowired
	private DeleteService deleteService;
	
	public DeleteController() {
		System.out.println(this.getClass().getSimpleName() + "Created....");
	}
	@RequestMapping(value = "/delete.do", method = RequestMethod.GET)
	public ModelAndView userDeleteController(HttpServletRequest request, DeleteDTO dto) {
		System.out.println("DeleteController() started");
		
		HttpSession session = request.getSession(true);
		boolean res =deleteService.deleteService(dto); 
		if (res) {
			System.out.println("DeleteController ended");
			return new ModelAndView("/DeleteSuccess.html");
		} else {
			System.out.println("DeleteController ended");			
			return new ModelAndView("/DeleteError.html");
		}
		
	}
}
		
