package com.JSpiders.Spring.controller.UpdateController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.Service.UpdateService.UpdateService;

@Component
@RequestMapping("/")
public class UpdateController {
	@Autowired
	private UpdateService service;

	public UpdateController() {
		System.out.println(this.getClass().getSimpleName() + "Created....");
	}

	@RequestMapping(value = "update.do", method = RequestMethod.POST)
	public ModelAndView userUpdateController(RegisterDTO dto, HttpServletRequest request) {
		System.out.println("userUpdateController() started");
		HttpSession session = request.getSession(false);
		RegisterDTO dtoFROMSession = (RegisterDTO) session.getAttribute("dto");
		int PK = dtoFROMSession.getId();
		System.out.println(dtoFROMSession);
		dto.setId(PK);

		RegisterDTO dtoFROMDB = service.userService(dto);
		if (dtoFROMDB != null) {
			session.setAttribute("dto", dtoFROMDB);
			System.out.println("userUpdateController() ended");

			return new ModelAndView("Home.html", "nmg", "Updated successfully");
		} else {
			System.out.println("userUpdateController() ended");
			return new ModelAndView("Update.html");
		}
	}
}
