package com.JSpiders.Spring.controller.register;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.Service.register.RegisterService;


@Component
@RequestMapping("/")
public class RegisterController {

	@Autowired
	private RegisterService service;

	public RegisterController() {
		System.out.println(this.getClass().getSimpleName() + "Created....");
	}

	@RequestMapping(value="/register.do",method=RequestMethod.POST)
	public ModelAndView registerUser(RegisterDTO dto) {
		System.out.println("Register user started....");

		service.createUser(dto);

		System.out.println("Register user ended....");
		return new ModelAndView("Success.html");
	}

}
