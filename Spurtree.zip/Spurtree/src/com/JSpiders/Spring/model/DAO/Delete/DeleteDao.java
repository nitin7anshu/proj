package com.JSpiders.Spring.model.DAO.Delete;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.JSpiders.Spring.DTO.delete.DeleteDTO;
import com.JSpiders.Spring.DTO.register.RegisterDTO;

@Repository
public class DeleteDao {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public DeleteDao() {
		System.out.println(this.getClass().getSimpleName()+"Created....");
	}
	public int delete(DeleteDTO dto){
		System.out.println("Save User started......");
		
		String hql = "delete from RegisterDTO R where R.emailId=:em";
		
		Session session=sessionFactory.openSession();
		Query qry = session.createQuery(hql);
		qry.setParameter("em", dto.getEmailID());
		Transaction tx=session.beginTransaction();
		int res = qry.executeUpdate();
		tx.commit();
		session.close();
		
		System.out.println("Save User deleted......");
		return res;
	}


}
