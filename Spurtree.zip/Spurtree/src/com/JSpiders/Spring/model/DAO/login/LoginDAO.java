package com.JSpiders.Spring.model.DAO.login;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.JSpiders.Spring.DTO.register.RegisterDTO;


@Repository
public class LoginDAO {
	
	@Autowired
	private SessionFactory session;

	public LoginDAO() {
		System.out.println(this.getClass().getSimpleName()+"Created....");
	}
	
public RegisterDTO fetch(RegisterDTO dto){
	System.out.println("Login DAO is started......");
	
	String hql="From RegisterDTO R where R.emailId=:em and R.password=:pwd";
	Session factory=session.openSession();
	Query qry=factory.createQuery(hql);
	
	qry.setParameter("em", dto.getEmailId());
	qry.setParameter("pwd",dto.getPassword());
	
	RegisterDTO dtoFROMDB=(RegisterDTO)qry.uniqueResult();
	
	System.out.println("Login DAO is ended......");
	return dtoFROMDB;
}
}
