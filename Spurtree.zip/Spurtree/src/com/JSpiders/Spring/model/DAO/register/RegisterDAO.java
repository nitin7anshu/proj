package com.JSpiders.Spring.model.DAO.register;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.JSpiders.Spring.DTO.register.RegisterDTO;


@Component
public class RegisterDAO {
	
	@Autowired
	private SessionFactory factory;

	public RegisterDAO() {
		System.out.println(this.getClass().getSimpleName()+"Created.....");
	}
	public void saveUser(RegisterDTO dto){
		System.out.println("Save User started......");
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(dto);
		tx.commit();
		session.close();
		
		System.out.println("Save User ended......");
	}

}
