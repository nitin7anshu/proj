package com.JSpiders.Spring.model.DAO.UpdateDAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.JSpiders.Spring.DTO.register.RegisterDTO;

@Repository
public class UpdateDAO {
	@Autowired
	SessionFactory sessionFactory;

	public UpdateDAO() {
		System.out.println(this.getClass().getSimpleName()+"Created....");
	}
	
	public RegisterDTO userDAO(RegisterDTO dto){
		
		System.out.println("userDAO started..");
		Session session=sessionFactory.openSession();
		
		Transaction tx=session.beginTransaction();
		RegisterDTO dtoFROMDB=(RegisterDTO) session.merge(dto);
		tx.commit();
		session.close();
		System.out.println("userDAO ended..");
		return dtoFROMDB;
		
	}

}
