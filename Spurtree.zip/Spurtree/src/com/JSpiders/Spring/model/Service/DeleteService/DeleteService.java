package com.JSpiders.Spring.model.Service.DeleteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JSpiders.Spring.DTO.delete.DeleteDTO;
import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.DAO.Delete.DeleteDao;
import com.JSpiders.Spring.model.DAO.login.LoginDAO;
@Service
public class DeleteService {

	@Autowired
	private DeleteDao deleteDao;

	public DeleteService() {
		System.out.println(this.getClass().getSimpleName()+"Created...");
	}
	public boolean deleteService(DeleteDTO dto){
		System.out.println("DeleteService started......");
		
		int r=deleteDao.delete(dto);
		if(r!=0){
			System.out.println("DeleteService ended");
			return true;
		}
		else{
		}
		System.out.println("DeleteService ended");
		return false;
	}
}
