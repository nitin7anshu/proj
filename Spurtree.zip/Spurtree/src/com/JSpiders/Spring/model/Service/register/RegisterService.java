package com.JSpiders.Spring.model.Service.register;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.DAO.register.RegisterDAO;


@Component
public class RegisterService {
	
	@Autowired
	private RegisterDAO dao;
	
	public RegisterService(){
		System.out.println(this.getClass().getSimpleName()+"Created...");
	}
	
		public void createUser(RegisterDTO dto){
			System.out.println("Register service started..");
			
			dao.saveUser(dto);
			
			System.out.println("Register service ended..");
		}
	
}
