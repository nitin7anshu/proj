package com.JSpiders.Spring.model.Service.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.DAO.login.LoginDAO;

@Service
public class LoginService {
	
	@Autowired
	private LoginDAO loginDao;

	public LoginService() {
		System.out.println(this.getClass().getSimpleName()+"Created...");
	}
	public RegisterDTO userLoginService(RegisterDTO dto){
		System.out.println("Login service is started......");
		
		RegisterDTO dtoFROMDB=loginDao.fetch(dto);
		
		System.out.println("Login service is ended......");
		return dtoFROMDB;
	}

}
