package com.JSpiders.Spring.model.Service.UpdateService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JSpiders.Spring.DTO.register.RegisterDTO;
import com.JSpiders.Spring.model.DAO.UpdateDAO.UpdateDAO;

@Service
public class UpdateService {
	@Autowired
	private UpdateDAO udao;

	public  UpdateService() {
		System.out.println(this.getClass().getSimpleName());
	}
	
	public RegisterDTO userService(RegisterDTO dto)
	{
		System.out.println("userService is started..");
		RegisterDTO dtoFROMDB=udao.userDAO(dto);
		System.out.println("userService is ended..");
		return dtoFROMDB;
		
	}

}
