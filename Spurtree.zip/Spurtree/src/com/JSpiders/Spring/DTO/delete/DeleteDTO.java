package com.JSpiders.Spring.DTO.delete;

import java.io.Serializable;

import org.springframework.stereotype.Component;
@Component
public class DeleteDTO implements Serializable{
private String emailID;

public String getEmailID() {
	return emailID;
}

public void setEmailID(String emailID) {
	this.emailID = emailID;
}

@Override
public String toString() {
	return "deleteDTO [emailID=" + emailID + "]";
}

}
